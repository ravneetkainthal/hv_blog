// src/types/index.ts
export type BlogProps = {
    _id: string;
    title: string;
    content: string;
    author: string;
    createdAt: string;
  };
  